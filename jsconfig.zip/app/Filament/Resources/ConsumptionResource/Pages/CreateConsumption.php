<?php

namespace App\Filament\Resources\ConsumptionResource\Pages;

use App\Filament\Resources\ConsumptionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateConsumption extends CreateRecord
{
    protected static string $resource = ConsumptionResource::class;
}
