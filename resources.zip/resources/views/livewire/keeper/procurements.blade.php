<?php

use App\Livewire\Actions\Logout;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Volt\Component;

new  class extends Component
{
    
    
}; 

?>

<div>
    <livewire:procurement-manager />
</div>
